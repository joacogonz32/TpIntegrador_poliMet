package com.polimet.museo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolimetApplicationTests {

	@Test
	void contextLoads() {
	}

}
